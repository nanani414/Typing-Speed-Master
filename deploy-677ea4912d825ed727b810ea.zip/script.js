let difficulty = 'easy';

function setDifficulty(level) {
    difficulty = level;
    resetGame();
    updateWord();
}

function updateWord() {
    const difficultyWords = {
        easy: ["cat", "dog", "fish", "book", "apple"],
        medium: ["banana", "elephant", "computer", "programming", "keyboard"],
        hard: ["supercalifragilisticexpialidocious", "uncharacteristically", "antidisestablishmentarianism", "counterproductive"]
    };
    const words = difficultyWords[difficulty];
    const randomIndex = Math.floor(Math.random() * words.length);
    currentWord = words[randomIndex];
    wordToType.textContent = currentWord;
}

function saveScore() {
    let highScore = localStorage.getItem('highScore');
    if (!highScore || correctWords > highScore) {
        localStorage.setItem('highScore', correctWords);
    }
    alert(`Game Over! Your best score is: ${localStorage.getItem('highScore')}`);
}


endGame() {
    gameStarted = false;
    clearInterval(interval);
    saveScore();  // Save the high score when the game ends
    startButton.disabled = false;
    userInput.disabled = true;
    userInput.value = '';
}

document.getElementById('best-score').textContent = localStorage.getItem('highScore') || 0;

let correctSound = new Audio('correct.wav');
let wrongSound = new Audio('wrong.wav');

function checkInput() {
    if (userInput.value === currentWord) {
        correctWords++;
        correctWordsDisplay.textContent = correctWords;
        wordsTyped++;
        wordsTypedDisplay.textContent = wordsTyped;
        correctSound.play();
        updateWord();
    } else {
        wrongSound.play();
    }
}

const themeToggleButton = document.getElementById('theme-toggle');

themeToggleButton.addEventListener('click', () => {
    document.body.classList.toggle('light');
    themeToggleButton.classList.toggle('light');
    themeToggleButton.classList.toggle('dark');
});

let timeLimit = 60; // default 1 minute

document.getElementById('time-limit').addEventListener('change', (event) => {
    timeLimit = parseInt(event.target.value);
});

function startTimer() {
    interval = setInterval(() => {
        if (gameStarted) {
            timer++;
            timerDisplay.textContent = timer;
            if (timer >= timeLimit) {
                endGame();
            }
        }
    }, 1000);
}

function checkInput() {
    if (userInput.value === currentWord) {
        correctWords++;
        correctWordsDisplay.textContent = correctWords;
        wordsTyped++;
        wordsTypedDisplay.textContent = wordsTyped;
        correctSound.play();
        wordToType.classList.add('correct');
        setTimeout(() => wordToType.classList.remove('correct'), 500);
        updateWord();
    } else {
        wrongSound.play();
        wordToType.classList.add('incorrect');
        setTimeout(() => wordToType.classList.remove('incorrect'), 500);
    }
}

